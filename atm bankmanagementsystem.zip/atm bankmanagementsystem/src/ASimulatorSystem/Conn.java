package ASimulatorSystem;

import java.sql.*;

public class Conn {
    Connection c;
    Statement s;

    public Conn() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            c = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/bankmanagementsystem", // Corrected URL with localhost and port
                "root",  // MySQL username
                " "   // MySQL password
            );

            // Create a statement object to execute queries
            s = c.createStatement();

        } catch (Exception e) {
            System.out.println("❌ Connection Error: " + e);
        }
    }
}
